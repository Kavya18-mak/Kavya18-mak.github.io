# MartialArtSimulator
It is a Martial Arts Simulator it  is a part of game in which martial artist is standing in idle position who is waiting for the commands to be issued. 
When we click any button on the bottom than martial artist will execute them in order.
